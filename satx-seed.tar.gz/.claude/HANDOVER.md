# Handover

**Written.** 2026-09-12, at the end of a design conversation that produced the specifications in `en/docs` and the decisions below.

**For.** A Claude Code session working in `/home/initial/2-areas/development/satx`.

## What this directory is

`satx` is a SAT instance that does three jobs at once.

**A fixture.** Something for a reader to be checked against. Every ruling in the sidecar specification is exercised by at least one node, so a reader can be tested against the document rather than against its author's memory of it.

**A prototype.** A worked example of the shape SAT MVP is being built toward.

**The first instance.** Instances are created by instances, so the first cannot be. `satx` is hand-built, and `satx/bin/sat init ../saty` creating a valid `saty` is the test that `init` works.

It is a sibling of SAT and of the website repository, owned by neither. A fixture living inside one of its consumers gets adjusted to suit that consumer, quietly, until it stops being an independent check.

## Read these first, in this order

They are in `en/docs`, and they are the authority. Where this note and a specification disagree, the specification is right.

1. `sat-sidecars-config-and-metadata-v0-0-12.md`, the core document: what a sidecar is, how the cascade composes, field kinds, rows, amendment.
2. `satx-shape-and-purpose-v0-0-7.md`, what to build here and why, including the tree, the three runs, and the error cases.
3. `sat-configuration-cascade-specification-v0-2-2.md`, the configuration tree, which metadata is a twin of.
4. `multilingual-ingress-requirements-v0-0-2.md`, what the website consumes downstream. Only matters once the reader works.

## The rulings least obvious from the documents

These came out of argument rather than from a first reading, and each has a reason that is easy to undo by accident.

**`order` lives on the work, not the expression.** "Projects before Areas" is the same fact in every language, so it belongs to the thing every language shares. Written per expression it is one fact stored twice, able to drift, and the English and French menus can disagree with nothing detecting it.

**`x-default` appears on the home work only.** It names where to send a visitor whose language is not published, and that destination exists only where the root is a language selector. A specific document has no language-neutral version, and naming the English one would assert that English is everyone's default.

**Local fields must not descend, and the failure is silent.** A directory whose resolved title is "wellbeing" would pass that title down, and a resource that never stated its own would publish as "wellbeing". Nothing reports it. This is why field kinds exist.

**Authority is administrative, not monotonic.** Configuration lets `overridable` narrow and never widen. Metadata lets a higher role widen what a lower one narrowed, because an administrator has to be able to correct a department. A lock binds everyone below and yields to everyone above, and so does deprecation. They are the same kind of act.

**`status: deprecated` removes an item from the resolved set and keeps it in the record.** Without the distinction between "nobody decided" and "someone decided against it", a rejected subject is re-proposed on every rebuild.

**Subject accumulates from ancestor works, not ancestor slugs.** Slugs are chosen for URLs, so `terms-of-service` and `2024` would arrive as subjects. Worse, the two language trees produce disjoint sets for one work, and nothing could answer "everything about wellbeing, in any language".

**Organizing directories hold no archived content, and may appear anywhere.** They are an accommodation: scans, staged ingress, binaries, working files. The single enforceable check is a content node found beneath a directory with no sidecar.

**Identity does not cascade.** `identifier` names one resource and `isVersionOf` names its work. A child inheriting either would become a duplicate of its parent, or an expression of its parent's work, which would make a section index and everything beneath it translations of each other.

## Two disciplines that matter more than they look

**When the reader and `satx` disagree, the question is what the document says.** Not which is faster to change. The whole value of building them as two readings of one specification is lost the moment one is adjusted to match the other without checking.

That property is already weakened: the same author wrote the JavaScript prototype reader and will influence this instance. The rule is what preserves what is left of it.

**A check nobody exercises is a check nobody knows is broken.** `content/errors/` exists for that reason and its table in the satx document is an acceptance criterion. A reader run against it should produce exactly that list. Fewer means a check is missing; more means a check is wrong.

## Toolchain

**Python, and `ruamel.yaml` with the modern `YAML()` API.** PyYAML implements YAML 1.1, where `no` is a boolean and also the ISO 639-1 code for Norwegian, so an unquoted language key parses as `False` with nothing visible in the file.

Two settings are not defaults and both matter:

- `yaml.preserve_quotes = True` on any instance that rewrites a file, or hand-written quotes are stripped by the tool that asked for them
- `DoubleQuotedScalarString` when generating values the specification says to quote, because a fresh `"no"` dumps unquoted and ruamel is correct by its own lights to do so

Round-trip for `overrides/`, which a person edits and comments. Safe for `defaults/` and `resolved/`, which are generated.

**Cross platform.** `pathlib` throughout, no shelling out, no assumption that `a.md` and `A.md` differ, explicit UTF-8, deliberate line endings. `satlib` is portable and the interpreter is portable; the bash tier dispatchers are not, and writing them in Python removes the gap rather than working around it.

## Where to start

**Build `satx` by hand**, following the tree in the satx document. Depth first: the instance root and its config, then one language archive with a handful of real documents, then the second and third.

**Then run a reader against it.** A JavaScript prototype exists and is at `reference/sat-reader-v0.0.1.tar.gz`. It is a prototype: the production reader is Python and belongs in SAT, because the specification says one resolver, not two kept in step. Read the prototype for what it got wrong as much as for what it got right; two decisions in it are marked in comments as not being in the specification.

**Then write `init`,** and check that `saty` reads clean.

## What is not here and is not blocked by this

Three improvements belong in `vishpala-eleventy-mvp` regardless of what happens in `satx`, because the Sveltia solution wants them too and none exists there: a sitemap with `xhtml:link` alternates, a `robots.txt`, and JSON-LD. `reference/` holds working versions of all three.
