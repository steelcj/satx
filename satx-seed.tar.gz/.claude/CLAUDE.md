# satx

A SAT instance that is a fixture, a prototype, and the first instance. Read `.claude/HANDOVER.md` before starting work, then the specifications in `en/docs`.

## Authority

The specifications in `en/docs` are the authority. Where anything here, in the handover note, or in existing code disagrees with them, the specification is right. Where the specification is silent, say so rather than choosing quietly.

## House style for markdown

These are enforced by `check-conformance.py` in the SAT repositories and apply to every document written here.

- Commas rather than em dashes. No em dashes at all.
- No heading numbers.
- No horizontal rules in content.
- No hard line wraps in prose.
- APA 7 citations using citation anchor pairs: an in-text anchor and a reference anchor with a return link.
- Hyphens rather than dots in versioned filenames: `name-v0-1-0.md`.
- Versioned documents carry a `**Version.**` line and a changes section.

Drafting history belongs in the changes section, not in the body. A reader has not seen the previous version. Contrast with something outside the document where it explains the product; contrast with an earlier draft of the same document only where a reader may have built against the earlier ruling.

## YAML

`ruamel.yaml` with the modern `YAML()` API. Never PyYAML: it is YAML 1.1, where `no` is a boolean and also the ISO 639-1 code for Norwegian.

- `yaml.preserve_quotes = True` on any instance that rewrites a file
- `DoubleQuotedScalarString` for language tags and slugs when generating
- round-trip for `overrides/`, safe for `defaults/` and `resolved/`

## Python

- `pathlib` throughout, never string concatenation for paths
- no shelling out to external commands
- no assumption that `a.md` and `A.md` are different files
- explicit UTF-8 on every read and write
- line endings chosen deliberately

## Working habits

**Verify rather than assert.** This project has repeatedly found that a thing which reads correctly on paper behaves differently when run. Where a claim is checkable, check it and report what came back.

**Report what a check found, including nothing.** A silent pass is indistinguishable from a check that never ran.

**Read a file before editing it.** Files here are edited outside the session and a prior version may not be what is on disk.

**Do not fix a disagreement between the reader and the instance unilaterally.** Ask what the specification says. The two are built as independent readings of one document and that property is the point.

## Vocabulary

`node` is a directory or file carrying a sidecar. `organizing directory` carries a boundary marker and no role. `work` is the abstract content; `expression` is one realisation of it; `identifier` names an expression and `isVersionOf` names its work. `role` is one of sat, collection, archive, directory, content, in rank order.

Say `node`, never `level`. The rename is done and `level` is a leftover from earlier drafts.
