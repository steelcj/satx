#!/usr/bin/env node
/**
 * check.js — assertions over the built site.
 *
 * Every check here guards a failure that is silent: the build succeeds, the
 * pages render, and something is wrong in a way nobody notices until a
 * crawler, a screen reader, or a domain change surfaces it.
 *
 *   node check.js            check ./_site
 *   node check.js _site      same
 *   node check.js --json     machine-readable output
 *
 * Exits 1 on any failure, so it can stand as the `test` script.
 */

import fs from "node:fs";
import path from "node:path";

const args = process.argv.slice(2);
const asJson = args.includes("--json");
const dir = args.find((a) => !a.startsWith("--")) || "_site";

const failures = [];
const notes = [];
const fail = (check, where, message) => failures.push({ check, where, message });

// ------------------------------------------------------------------ collect

function walk(d, out = []) {
  if (!fs.existsSync(d)) return out;
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    const full = path.join(d, e.name);
    if (e.isDirectory()) walk(full, out);
    else out.push(full);
  }
  return out;
}

const files = walk(dir);
const htmlFiles = files.filter((f) => f.endsWith(".html"));

// The build produced nothing. Eleventy reports this as success, which is how
// an empty deploy reaches production.
if (htmlFiles.length === 0) {
  fail("build", dir, "no HTML files; an empty build is not a successful one");
}

const pages = new Map(); // url -> parsed facts
for (const file of htmlFiles) {
  const html = fs.readFileSync(file, "utf8");
  const rel = "/" + path.relative(dir, file).replace(/index\.html$/, "");
  pages.set(rel, {
    file,
    html,
    lang: (html.match(/<html[^>]*\blang="([^"]*)"/) || [])[1],
    canonical: (html.match(/rel="canonical"[^>]*href="([^"]*)"/) || [])[1],
    alternates: [...html.matchAll(/rel="alternate"[^>]*hreflang="([^"]*)"[^>]*href="([^"]*)"/g)]
      .map((m) => ({ lang: m[1], href: m[2] })),
    jsonld: [...html.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)]
      .map((m) => m[1]),
    title: (html.match(/<title>([^<]*)<\/title>/) || [])[1],
  });
}

// ------------------------------------------------------------------- checks

// 1. Every page states a language, and states it as a well-formed lowercase tag.
for (const [url, p] of pages) {
  if (url === "/") continue; // the selector is not archive content
  if (!p.lang) fail("lang", url, "no lang attribute on <html>");
  else if (p.lang !== p.lang.toLowerCase())
    fail("lang", url, `lang "${p.lang}" is not lowercase; the archive uses one casing throughout`);
  else if (!/^[a-z]{2,3}(-[a-z0-9]+)*$/.test(p.lang))
    fail("lang", url, `lang "${p.lang}" is not a well-formed BCP 47 tag`);
}

// 2. No page advertises the same hreflang twice. Two links with one tag and
//    different URLs cannot be resolved, and the whole annotation set is
//    discarded rather than the offending line.
for (const [url, p] of pages) {
  const seen = new Map();
  for (const a of p.alternates) {
    if (a.lang === "x-default") continue;
    if (seen.has(a.lang) && seen.get(a.lang) !== a.href)
      fail("hreflang-duplicate", url, `hreflang "${a.lang}" declared twice with different targets`);
    seen.set(a.lang, a.href);
  }
}

// 3. hreflang is reciprocal. An annotation a consumer cannot confirm from the
//    other end is ignored, so a one-way link is the same as no link.
const byHref = new Map();
for (const [url, p] of pages) {
  for (const a of p.alternates) {
    if (a.lang === "x-default") continue;
    const target = a.href.replace(/^https?:\/\/[^/]+/, "");
    if (!byHref.has(url)) byHref.set(url, []);
    byHref.get(url).push(target);
  }
}
for (const [url, targets] of byHref) {
  // The root selector is noindex and outside the archive: it points at the
  // language homes, and they do not point back at it. Not a reciprocal set.
  if (url === "/") continue;
  for (const t of targets) {
    if (t === url) continue; // self-reference is expected
    if (!pages.has(t)) {
      fail("hreflang-target", url, `alternate points at ${t}, which was not built`);
      continue;
    }
    const back = byHref.get(t) || [];
    if (!back.includes(url)) fail("hreflang-reciprocal", url, `alternate to ${t} is not returned`);
  }
}

// 4. Every JSON-LD block parses, and is not HTML-escaped. Dropping `| safe`
//    in Nunjucks produces &quot; entities: the page looks correct and the
//    graph is unreadable.
for (const [url, p] of pages) {
  for (const raw of p.jsonld) {
    if (raw.includes("&quot;")) {
      fail("jsonld", url, "JSON-LD is HTML-escaped; a `| safe` filter is missing");
      continue;
    }
    try {
      JSON.parse(raw);
    } catch (e) {
      fail("jsonld", url, `JSON-LD does not parse: ${e.message}`);
    }
  }
  if (url !== "/" && p.jsonld.length === 0) notes.push(`${url}: no JSON-LD block`);
}

// 5. Canonicals are absolute. A relative canonical resolves against the
//    document and misleads anything reading the page out of context.
for (const [url, p] of pages) {
  if (url === "/") continue;
  if (!p.canonical) fail("canonical", url, "no canonical link");
  else if (!/^https?:\/\//.test(p.canonical))
    fail("canonical", url, `canonical "${p.canonical}" is not absolute`);
}

// 6. Sitemap agrees with the pages. hreflang is declared in two places now,
//    so each must be checked against the other rather than alone.
const sitemapPath = path.join(dir, "sitemap.xml");
if (!fs.existsSync(sitemapPath)) {
  fail("sitemap", "sitemap.xml", "missing");
} else {
  const xml = fs.readFileSync(sitemapPath, "utf8");

  if (!xml.includes('xmlns:xhtml="http://www.w3.org/1999/xhtml"'))
    fail("sitemap", "sitemap.xml", "xhtml namespace not declared on urlset; alternates will be ignored");

  const entries = [...xml.matchAll(/<url>([\s\S]*?)<\/url>/g)].map((m) => {
    const body = m[1];
    return {
      loc: (body.match(/<loc>([^<]*)<\/loc>/) || [])[1],
      alts: [...body.matchAll(/hreflang="([^"]*)"\s+href="([^"]*)"/g)].map((a) => ({
        lang: a[1],
        href: a[2],
      })),
    };
  });

  const locPaths = new Set(entries.map((e) => (e.loc || "").replace(/^https?:\/\/[^/]+/, "")));

  for (const [url] of pages) {
    if (url === "/") continue; // the selector is noindex and excluded on purpose
    if (!locPaths.has(url)) fail("sitemap", url, "built page is not listed in the sitemap");
  }
  for (const p of locPaths) {
    if (!pages.has(p)) fail("sitemap", p, "sitemap lists a URL that was not built");
  }
  if (locPaths.has("/sitemap.xml")) fail("sitemap", "sitemap.xml", "sitemap lists itself");

  // Head and sitemap must state the same relationships.
  for (const e of entries) {
    const url = (e.loc || "").replace(/^https?:\/\/[^/]+/, "");
    const page = pages.get(url);
    if (!page) continue;
    const head = new Set(page.alternates.filter((a) => a.lang !== "x-default").map((a) => a.lang));
    const smap = new Set(e.alts.filter((a) => a.lang !== "x-default").map((a) => a.lang));
    if (head.size === 0 && smap.size === 0) continue;
    const diff = [...new Set([...head, ...smap])].filter((l) => head.has(l) !== smap.has(l));
    if (diff.length)
      fail("sitemap-agreement", url, `head and sitemap disagree on hreflang: ${diff.join(", ")}`);
  }
}

// 7. robots.txt exists and names an absolute sitemap.
const robotsPath = path.join(dir, "robots.txt");
if (!fs.existsSync(robotsPath)) {
  fail("robots", "robots.txt", "missing");
} else {
  const robots = fs.readFileSync(robotsPath, "utf8");
  const line = (robots.match(/^Sitemap:\s*(.*)$/m) || [])[1];
  if (!line) fail("robots", "robots.txt", "no Sitemap line");
  else if (!/^https?:\/\//.test(line.trim()))
    fail("robots", "robots.txt", `Sitemap "${line.trim()}" is not absolute; a data value is probably empty`);
}

// 8. One domain throughout. Catches a half-applied domain change, where some
//    files are regenerated and others are stale.
const hosts = new Set();
for (const [, p] of pages) {
  for (const m of p.html.matchAll(/https?:\/\/([^/"'\s]+)/g)) {
    const h = m[1];
    if (h.includes(".w3.org") || h.includes("purl.org") || h.includes("dublincore.org")) continue;
    if (h.includes("schema.org") || h.includes("ns.dublincore.org")) continue;
    hosts.add(h);
  }
}
if (hosts.size > 1)
  fail("domain", dir, `more than one site host in the output: ${[...hosts].join(", ")}`);

// ------------------------------------------------------------------ report

if (asJson) {
  console.log(JSON.stringify({ pages: pages.size, failures, notes }, null, 2));
} else {
  console.log(`checked ${pages.size} page(s) in ${dir}\n`);
  for (const f of failures) console.error(`FAIL  [${f.check}] ${f.where}: ${f.message}`);
  for (const n of notes) console.error(` note  ${n}`);
  if (failures.length === 0) console.log("all checks passed");
  else console.error(`\n${failures.length} failure(s)`);
}

process.exit(failures.length ? 1 : 0);
