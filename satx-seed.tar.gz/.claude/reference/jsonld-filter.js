  eleventyConfig.addFilter("jsonld", (iri, sat, dc, translations) =>
    JSON.stringify(
      {
        "@context": {
          "@vocab": "http://purl.org/dc/elements/1.1/",
          openwemi: "https://ns.dublincore.org/openwemi/",
          dcmitype: "http://purl.org/dc/dcmitype/",
        },
        "@id": iri.self,
        "@type": ["openwemi:Expression", "dcmitype:Text"],
        identifier: sat.identifier,
        title: dc.title[0],
        language: dc.language[0],
        format: dc.format[0],
        "openwemi:expresses": {
          "@id": iri.work,
          identifier: sat.isVersionOf,
          "openwemi:expressedBy": (translations || []).map((t) => t.iri),
        },
      },
      null,
      2
    )
  );
