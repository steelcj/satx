# reference

Working artifacts from the design conversation. None of this is `satx` content. It is here to be read, borrowed from, and in one case corrected.

## `sat-reader-v0.0.1.tar.gz`

A JavaScript prototype reader, written from the sidecar specification. It runs, and a smoke test confirms five rules fire: contextual fields descending, local fields not descending, rows and placement, deprecation removing from the consumer view while staying in the record, and a lower tier writing into a higher row being reported.

**It is a prototype and should not become the production reader.** The specification says one resolver, not two kept in step. SAT is Python, so the production reader is Python and belongs in SAT. Read this for what it worked out, not as a thing to translate line by line, and be aware that translating it rather than writing from the document destroys the independence the fixture exists to provide.

**Two decisions in it are not in the specification** and are marked in comments where they occur:

- where amendments apply in the sequence, placed after composition so they act on what the node holds
- what happens when a local item restates an inherited one of the same value in an accumulating row, made a lock check with an inert marker, by analogy with contextual fields

Both need ruling rather than inheriting.

**It predates the boundary marker.** Its `isNode` treats absence of a sidecar as meaning organizing. The specification now has `.sat-boundary` inside the sidecar, so absence is an error and the marker is the signal.

## `check.js`, `sitemap.njk`, `robots.njk`, `jsonld-filter.js`

Eight output assertions and three things a built site should have. These belong in `vishpala-eleventy-mvp`, which has none of them, and they are independent of everything in `satx`.

`check.js` found two real defects the first time it ran, and each of the failures it guards has occurred at least once during development: an empty build reported as success, JSON-LD silently HTML-escaped by a missing template filter, duplicate `hreflang` tags, a half-applied domain change leaving stale references.

The sitemap carries `xhtml:link` alternates and guards against emitting a single-item alternate set, which says nothing that `<loc>` has not already said.

They are Eleventy-specific and have no place in a SAT instance. They are here because the session that produced them is ending and they would otherwise be lost.
